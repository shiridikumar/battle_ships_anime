import json
import urllib.request
import math
import random
import bpy
import shutil
from . import general
from pathlib import Path
from .general import utiliser_ciel, sky_rotation_updated, composite_sky_colors_updated
from . import bl_info


class SS_OT_check_latest_version(bpy.types.Operator):
	bl_idname = 'world.ss_check_latest_version'
	bl_description = "If you want to know if there's a new version released since your current version"
	bl_label = 'Check new version'

	def execute(self, context):
		general.error_occured_during_version_checking = False
		general.latest_checked_version_is_newer = None
		general.latest_checked_version = None
		try:
			with urllib.request.urlopen("https://www.cgchan.com/static/sceneskies_updates.json") as url:
				data = json.loads(url.read().decode())
				general.latest_checked_version = data['latest_version']
				version_major_latest, version_minor_latest, version_bugfix_latest = general.latest_checked_version.split('.')
				version_major_current, version_minor_current, version_bugfix_current = bl_info['version']
				if int(version_major_latest) > int(version_major_current):
					general.latest_checked_version_is_newer = True
				elif int(version_minor_latest) > int(version_minor_current):
					general.latest_checked_version_is_newer = True
				elif int(version_bugfix_latest) > int(version_bugfix_current):
					general.latest_checked_version_is_newer = True
				else:
					general.latest_checked_version_is_newer = False
		except Exception as e:
			general.error_occured_during_version_checking = True
			print(e)

		return {'FINISHED'}


class SS_OT_render_cube_faces(bpy.types.Operator):
	bl_idname = 'world.ss_render_cube_faces'
	bl_description = "Render 6 cube faces of your scene (eg for game engines). " \
					 "Camera will be at 3d cursor's position. " \
					 "Render settings are the current ones. " \
					 "Open the console to see the progress"
	bl_label = 'Render skybox / cubemap'

	@classmethod
	def poll(cls, context):
		return context.mode == 'OBJECT'

	def execute(self, context):
		# créer et positionner caméra
		cam_data = bpy.data.cameras.new('SceneSkies cube faces')
		cam_data.type = 'PERSP'
		cam_data.lens_unit = 'FOV'
		cam_data.angle = math.radians(90)
		cam_object = bpy.data.objects.new('SceneSkies cube faces camera', cam_data)
		context.scene.collection.objects.link(cam_object)
		cam_object.location = bpy.context.scene.cursor.location
		previous_cam_object = context.scene.camera
		context.scene.camera = cam_object

		# changer les render settings nécessaires
		render_settings = bpy.context.scene.render
		previous_render_res_y = render_settings.resolution_y
		render_settings.resolution_y = render_settings.resolution_x
		previous_render_filepath = render_settings.filepath
		output_folder_path = Path(render_settings.filepath)
		if output_folder_path.is_file():
			output_folder_path = output_folder_path.parent

		# faire les rendus
		camera_rotations = [
			(0, 0, -90, 'bottom'),
			(180, 0, -90, 'top'),
			(90, 0, 0, '+y'),
			(90, 0, 90, '-x'),
			(90, 0, 180, '-y'),
			(90, 0, 270, '+x'),
		]
		for camera_rotation in camera_rotations:
			cam_object.rotation_euler[0] = math.radians(camera_rotation[0])
			cam_object.rotation_euler[1] = math.radians(camera_rotation[1])
			cam_object.rotation_euler[2] = math.radians(camera_rotation[2])
			render_settings.filepath = str(output_folder_path / ('cube_face_' + camera_rotation[3]))
			bpy.ops.render.render(write_still=True)

		# nettoyer
		render_settings.resolution_y = previous_render_res_y
		render_settings.filepath = previous_render_filepath
		context.scene.collection.objects.unlink(cam_object)
		bpy.data.objects.remove(cam_object)
		bpy.data.cameras.remove(cam_data)
		context.scene.camera = previous_cam_object

		self.report({'INFO'}, 'Images saved in: ' + str(output_folder_path))
		# self.report({'INFO'}, 'Images saved in current output folder: ')
		return {'FINISHED'}


class SS_OT_detect_collections(bpy.types.Operator):
	bl_idname = 'world.ss_detect_collections'
	bl_description = 'Find all your installed skies collections'
	bl_label = 'List installed collections'

	@classmethod
	def poll(cls, context):
		return context.mode == 'OBJECT'

	def execute(self, context):
		bpy.context.scene.SceneSkies_collections.clear()

		collections_dirs = [path for path in Path(bpy.context.preferences.addons['sceneskies'].preferences.storage_path).glob('*') if path.is_dir()]
		for collection_dir in collections_dirs:
			new_item = bpy.context.scene.SceneSkies_collections.add()
			new_item.name = collection_dir.name
			resolution_dirs = [path for path in collection_dir.glob('*') if path.is_dir()]
			for resolution_dir in resolution_dirs:
				if resolution_dir.name == '4000': new_item.collection_4k_is_installed = True
				elif resolution_dir.name == '8000': new_item.collection_8k_is_installed = True
				elif resolution_dir.name == '12000': new_item.collection_12k_is_installed = True
				elif resolution_dir.name == '16000': new_item.collection_16k_is_installed = True
				else: new_item.collection_other_res_are_installed = True

		bpy.context.scene.SceneSkies_collections_index = 0
		return {'FINISHED'}


class SS_OT_create_data_folder(bpy.types.Operator):
	bl_idname = 'world.ss_create_data_folder'
	bl_description = ''
	bl_label = 'Create'

	def execute(self, context):
		data_folder_path = Path(bpy.context.preferences.addons['sceneskies'].preferences.storage_path)
		data_folder_path.mkdir()
		return {'FINISHED'}


class SS_OT_add_samples_in_data_folder(bpy.types.Operator):
	bl_idname = 'world.ss_add_samples_in_data_folder'
	bl_description = ''
	bl_label = 'Add samples'

	def execute(self, context):
		sample_folder_path_src = Path(__file__).parent / 'Samples'
		sample_folder_path_dst = Path(bpy.context.preferences.addons['sceneskies'].preferences.storage_path) / 'Samples'
		shutil.copytree(str(sample_folder_path_src), str(sample_folder_path_dst))
		return {'FINISHED'}


class SS_OT_choisir_monde(bpy.types.Operator):
	bl_idname = 'world.ss_choisir_monde'
	bl_description = 'This will replace the world of the current scene with a new preset. (in Object mode only)'
	bl_label = 'Set sky'

	@classmethod
	def poll(cls, context):
		return context.mode == 'OBJECT'

	def execute(self, context):
		utiliser_ciel(context.scene.SceneSkies_previews)
		sky_rotation_updated(None, None)
		composite_sky_colors_updated(None, None)
		return {'FINISHED'}


class SS_OT_random_rotation(bpy.types.Operator):
	bl_idname = 'world.ss_random_rotation'
	bl_description = '(in Object mode only)'
	bl_label = 'Randomize rotation'

	@classmethod
	def poll(cls, context):
		return context.mode == 'OBJECT'

	def execute(self, context):
		bpy.context.scene.SceneSkies.rotation = random.uniform(0, 360)
		return {'FINISHED'}


class SS_OT_random_sun_dawn_color(bpy.types.Operator):
	bl_idname = 'world.ss_random_sun_dawn_color'
	bl_description = '(in Object mode only)'
	bl_label = 'Random dawn sun color'

	@classmethod
	def poll(cls, context):
		return context.mode == 'OBJECT'

	def execute(self, context):
		green = random.uniform(60, 100)
		red = green * random.uniform(.6, 1)
		bpy.context.scene.SceneSkies.sun_red_percent = red
		bpy.context.scene.SceneSkies.sun_green_percent = green
		bpy.context.scene.SceneSkies.sun_blue_percent = 100
		composite_sky_colors_updated(None, None)
		return {'FINISHED'}


class SS_OT_random_sun_noon_color(bpy.types.Operator):
	bl_idname = 'world.ss_random_sun_noon_color'
	bl_description = '(in Object mode only)'
	bl_label = 'Random noon sun color'

	@classmethod
	def poll(cls, context):
		return context.mode == 'OBJECT'

	def execute(self, context):
		bpy.context.scene.SceneSkies.sun_red_percent = 100
		bpy.context.scene.SceneSkies.sun_green_percent = 100
		bpy.context.scene.SceneSkies.sun_blue_percent = random.uniform(90, 100)
		composite_sky_colors_updated(None, None)
		return {'FINISHED'}


class SS_OT_random_sun_dusk_color(bpy.types.Operator):
	bl_idname = 'world.ss_random_sun_dusk_color'
	bl_description = '(in Object mode only)'
	bl_label = 'Random dusk sun color'

	@classmethod
	def poll(cls, context):
		return context.mode == 'OBJECT'

	def execute(self, context):
		bpy.context.scene.SceneSkies.sun_red_percent = 100
		bpy.context.scene.SceneSkies.sun_green_percent = random.uniform(50, 100)
		bpy.context.scene.SceneSkies.sun_blue_percent = random.uniform(50, 100)
		composite_sky_colors_updated(None, None)
		return {'FINISHED'}


class SS_OT_random_atmo_color(bpy.types.Operator):
	bl_idname = 'world.ss_random_atmo_color'
	bl_description = '(in Object mode only)'
	bl_label = 'Random color of the atmosphere'

	@classmethod
	def poll(cls, context):
		return context.mode == 'OBJECT'

	def execute(self, context):
		green = random.uniform(85, 120)
		red = green * random.uniform(.85, 1)
		bpy.context.scene.SceneSkies.atmo_red_percent = red
		bpy.context.scene.SceneSkies.atmo_green_percent = green
		bpy.context.scene.SceneSkies.atmo_blue_percent = random.uniform(90, 120)
		composite_sky_colors_updated(None, None)
		return {'FINISHED'}


class SS_OT_random_clouds_color(bpy.types.Operator):
	bl_idname = 'world.ss_random_clouds_color'
	bl_description = '(in Object mode only)'
	bl_label = 'Random clouds strength'

	@classmethod
	def poll(cls, context):
		return context.mode == 'OBJECT'

	def execute(self, context):
		bpy.context.scene.SceneSkies.cloudDirect_v = random.uniform(50, 150)
		bpy.context.scene.SceneSkies.cloudIndirect_v = random.uniform(50, 150)
		composite_sky_colors_updated(None, None)
		return {'FINISHED'}


class SS_OT_reset_sun(bpy.types.Operator):
	bl_idname = 'world.ss_reset_sun'
	bl_description = '(in Object mode only)'
	bl_label = 'Reset sun'

	@classmethod
	def poll(cls, context):
		return context.mode == 'OBJECT'

	def execute(self, context):
		bpy.context.scene.SceneSkies.sun_strength = 5
		bpy.context.scene.SceneSkies.sun_red_percent = 100
		bpy.context.scene.SceneSkies.sun_green_percent = 100
		bpy.context.scene.SceneSkies.sun_blue_percent = 100
		composite_sky_colors_updated(None, None)
		return {'FINISHED'}


class SS_OT_reset_atmo(bpy.types.Operator):
	bl_idname = 'world.ss_reset_atmo'
	bl_description = '(in Object mode only)'
	bl_label = 'Reset atmosphere'

	@classmethod
	def poll(cls, context):
		return context.mode == 'OBJECT'

	def execute(self, context):
		bpy.context.scene.SceneSkies.atmo_red_percent = 100
		bpy.context.scene.SceneSkies.atmo_green_percent = 100
		bpy.context.scene.SceneSkies.atmo_blue_percent = 100
		bpy.context.scene.SceneSkies.atmo_saturation = 100
		bpy.context.scene.SceneSkies.atmoDirect_v = 100
		bpy.context.scene.SceneSkies.atmoIndirect_v = 100
		composite_sky_colors_updated(None, None)
		return {'FINISHED'}


class SS_OT_reset_clouds(bpy.types.Operator):
	bl_idname = 'world.ss_reset_clouds'
	bl_description = '(in Object mode only)'
	bl_label = 'Reset clouds'

	@classmethod
	def poll(cls, context):
		return context.mode == 'OBJECT'

	def execute(self, context):
		bpy.context.scene.SceneSkies.cloudDirect_v = 100
		bpy.context.scene.SceneSkies.cloudIndirect_v = 100
		composite_sky_colors_updated(None, None)
		return {'FINISHED'}


class SS_OT_reset_surf(bpy.types.Operator):
	bl_idname = 'world.ss_reset_surf'
	bl_description = '(in Object mode only)'
	bl_label = 'Reset ground surface'

	@classmethod
	def poll(cls, context):
		return context.mode == 'OBJECT'

	def execute(self, context):
		bpy.context.scene.SceneSkies.surfDirect_red_percent = 100
		bpy.context.scene.SceneSkies.surfDirect_green_percent = 100
		bpy.context.scene.SceneSkies.surfDirect_blue_percent = 100
		bpy.context.scene.SceneSkies.surfDirect_saturation = 100
		bpy.context.scene.SceneSkies.surfDirect_value = 100

		bpy.context.scene.SceneSkies.surfIndirect_red_percent = 100
		bpy.context.scene.SceneSkies.surfIndirect_green_percent = 100
		bpy.context.scene.SceneSkies.surfIndirect_blue_percent = 100
		bpy.context.scene.SceneSkies.surfIndirect_saturation = 100
		bpy.context.scene.SceneSkies.surfIndirect_value = 100
		composite_sky_colors_updated(None, None)
		return {'FINISHED'}


class SS_OT_open_skies_folder(bpy.types.Operator):
	bl_idname = 'world.ss_open_skies_folder'
	bl_description = 'If you need to manage your skies/environment files'
	bl_label = 'Open images folder'

	def execute(self, context):
		bpy.ops.wm.path_open(filepath='C:/')
		return {'FINISHED'}
