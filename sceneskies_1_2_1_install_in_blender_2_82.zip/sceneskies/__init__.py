bl_info = {
	'name': 'SceneSkies',
	'author': 'Arnaud Couturier (couturier.arnaud@gmail.com), alias piiichan on the BlenderArtists forum',
	'version': (1, 2, 1),
	'blender': (2, 82, 0),
	'location': 'Properties Panel > World settings',
	'description': 'HDRs that you can color-tweak. Add collections to have more choice, check the website.',
	'category': 'World',
	'link': 'https://www.cgchan.com/sceneskies',
	'wiki_url': 'https://docs.google.com/document/d/1MYzeBaLsXOgPO6NsbXWGoaeGYfz0mX5qJOfklPb4zoc/edit?usp=sharing',
}

icônes = None
should_reload_thumbnails = False

if 'bpy' in locals():
	import importlib
	importlib.reload(general)
	importlib.reload(operators)
else:
	import bpy
	import bpy.utils.previews
	from pathlib import Path
	from . import general
	from . import operators


class SceneSkiesAddonPreferences(bpy.types.AddonPreferences):
	# this must match the addon name, use '__package__'
	# when defining this in a submodule of a python package.
	bl_idname = __name__

	storage_path: bpy.props.StringProperty(
		name="Data folder",
		description="The folder where you store your skies. Recommended somewhere among your documents",
		default=str(Path.home() / 'SceneSkies'),
		# update=update_panel
	)
	delete_old_worlds: bpy.props.BoolProperty(
		name="Automatically delete old worlds and images datablocks when selecting new skies",
		description="Recommended. HDR images can quickly eat up a lot of RAM, and this will ensure unused old SceneSkies worlds and images "
					"(those with a name starting with SceneSkies) will be deleted each time you load a new one",
		default=True,
	)

	def draw(self, context):
		layout = self.layout

		layout.operator("wm.url_open", text="Go to home / download page").url = "https://www.cgchan.com/sceneskies"

		row = layout.row()
		split = row.split(factor=0.65)
		split.prop(self, "storage_path")

		row = split.row()
		row.operator(operators.SS_OT_create_data_folder.bl_idname)
		data_folder_path = Path(bpy.context.preferences.addons['sceneskies'].preferences.storage_path)
		row.enabled = not data_folder_path.exists()

		row = split.row()
		row.operator(operators.SS_OT_add_samples_in_data_folder.bl_idname)
		sample_folder_path = data_folder_path / 'samples'
		row.enabled = not sample_folder_path.exists()

		layout.prop(self, "delete_old_worlds")

		# version checking
		layout.operator(operators.SS_OT_check_latest_version.bl_idname)
		if general.error_occured_during_version_checking:
			layout.label(text='Error. Check your internet connexion, see the console, or check the website', icon='ERROR')
		if general.latest_checked_version_is_newer is None:
			pass
		elif general.latest_checked_version_is_newer:
			layout.label(text='A newer version is available: ' + general.latest_checked_version)
		else:
			layout.label(text='All good, you have the latest version!', icon_value=icônes['tick'].icon_id)


def collections_index_updated(self, context):
	load_thumbnails_for_selected_collection()


class SS_PT_World(bpy.types.Panel):
	bl_region_type = 'WINDOW'
	bl_space_type = 'PROPERTIES'
	bl_context = 'world'
	bl_label = 'SceneSkies'

	def draw_header(self, context):
		global icônes
		self.layout.label(text='', icon_value=icônes['logo'].icon_id)

	def draw(self, context):
		self.layout.operator(operators.SS_OT_render_cube_faces.bl_idname)

		# no data folder yet
		data_folder_path = Path(bpy.context.preferences.addons['sceneskies'].preferences.storage_path)
		if len(context.scene.SceneSkies_collections) <= 0 and not data_folder_path.exists():
			self.layout.label(text="Data folder does not exist (see addon prefs)")
			self.layout.operator(operators.SS_OT_create_data_folder.bl_idname)

		# no collections yet => propose to install samples
		# sample_folder_path = data_folder_path / 'samples'

		# if len(context.scene.SceneSkies_collections) <= 0 and not sample_folder_path.exists():
		if len(context.scene.SceneSkies_collections) <= 0:
			total_installed_collections = 0
			try:
				for path in data_folder_path.glob('*'):
					if path.is_dir():
						total_installed_collections += 1
			except:
				pass
			if total_installed_collections <= 0:
				self.layout.label(text="No HDRs yet, you must add collections")
				self.layout.operator(operators.SS_OT_add_samples_in_data_folder.bl_idname)
				return

		# we have collections but no thumbnails loaded yet
		# if len(context.scene.SceneSkies_collections) > 0 and len(bpy.context.scene.SceneSkies_previews) <= 0:
		# 	self.layout.label(text="Reload addons with F8 or restart Blender to see thumbnails")
		#	return

		row = self.layout.row()
		row.operator(operators.SS_OT_detect_collections.bl_idname)
		row = self.layout.row()
		row.template_list("SS_UL_SkiesCollectionsList", "The_List", context.scene, "SceneSkies_collections", context.scene, "SceneSkies_collections_index")

		try:
			if should_reload_thumbnails:
				load_thumbnails_for_selected_collection()

			context.scene.SceneSkies_previews  # lance volontairement une exception quand previews pas encore existantes pour stopper le reste
			self.layout.template_icon_view(context.scene, 'SceneSkies_previews')

			row = self.layout.row()
			row.prop(context.scene.SceneSkies, 'should_load_composite')
			row.operator(operators.SS_OT_choisir_monde.bl_idname)

			world_nodes = context.world.node_tree.nodes

			row = self.layout.row()
			row.prop(context.scene.SceneSkies, 'rotation')
			row.operator(operators.SS_OT_random_rotation.bl_idname)
			row.enabled = 'sky_rotation' in world_nodes

			row = self.layout.row()
			row.prop(context.scene.SceneSkies, 'ui_property_groups', expand=True)
			row.enabled = 'equi_atmoDirect' in world_nodes

			if context.scene.SceneSkies.ui_property_groups == 'sun':
				layout = self.layout.column()
				layout.prop(context.scene.SceneSkies, 'sun_strength')
				layout.prop(context.scene.SceneSkies, 'sun_red_percent')
				layout.prop(context.scene.SceneSkies, 'sun_green_percent')
				layout.prop(context.scene.SceneSkies, 'sun_blue_percent')

				layout.operator(operators.SS_OT_random_sun_dawn_color.bl_idname)
				layout.operator(operators.SS_OT_random_sun_noon_color.bl_idname)
				layout.operator(operators.SS_OT_random_sun_dusk_color.bl_idname)
				layout.operator(operators.SS_OT_reset_sun.bl_idname)
				layout.enabled = 'final curves' in world_nodes

			elif context.scene.SceneSkies.ui_property_groups == 'atmosphere':
				layout = self.layout.column()
				layout.prop(context.scene.SceneSkies, 'atmo_red_percent')
				layout.prop(context.scene.SceneSkies, 'atmo_green_percent')
				layout.prop(context.scene.SceneSkies, 'atmo_blue_percent')
				layout.prop(context.scene.SceneSkies, 'atmo_saturation')
				layout.prop(context.scene.SceneSkies, 'atmoDirect_v')
				layout.prop(context.scene.SceneSkies, 'atmoIndirect_v')
				layout.operator(operators.SS_OT_random_atmo_color.bl_idname)
				layout.operator(operators.SS_OT_reset_atmo.bl_idname)
				layout.enabled = 'equi_atmoDirect' in world_nodes

			elif context.scene.SceneSkies.ui_property_groups == 'clouds':
				layout = self.layout.column()
				layout.prop(context.scene.SceneSkies, 'cloudDirect_v')
				layout.prop(context.scene.SceneSkies, 'cloudIndirect_v')
				layout.operator(operators.SS_OT_random_clouds_color.bl_idname)
				layout.operator(operators.SS_OT_reset_clouds.bl_idname)
				layout.enabled = 'equi_cloudDirect' in world_nodes and 'equi_cloudIndirect' in world_nodes

			elif context.scene.SceneSkies.ui_property_groups == 'surface':
				layout = self.layout.column()
				layout.label(text='Direct light')
				layout.prop(context.scene.SceneSkies, 'surfDirect_red_percent')
				layout.prop(context.scene.SceneSkies, 'surfDirect_green_percent')
				layout.prop(context.scene.SceneSkies, 'surfDirect_blue_percent')
				layout.prop(context.scene.SceneSkies, 'surfDirect_saturation')
				layout.prop(context.scene.SceneSkies, 'surfDirect_value')
				layout.label(text='Indirect light')
				layout.prop(context.scene.SceneSkies, 'surfIndirect_red_percent')
				layout.prop(context.scene.SceneSkies, 'surfIndirect_green_percent')
				layout.prop(context.scene.SceneSkies, 'surfIndirect_blue_percent')
				layout.prop(context.scene.SceneSkies, 'surfIndirect_saturation')
				layout.prop(context.scene.SceneSkies, 'surfIndirect_value')
				layout.label(text='')
				layout.operator(operators.SS_OT_reset_surf.bl_idname)
				layout.enabled = 'equi_surfDirect' in world_nodes and 'equi_cloudIndirect' in world_nodes
		except Exception as e:
			pass


class PropertyGroup_Scene(bpy.types.PropertyGroup):
	monde_chemin: bpy.props.StringProperty()

	should_load_composite: bpy.props.BoolProperty(
		name='Color tweaking',
		default=False,
		description="When enabled you'll be able to tweak the colors of various parts of the sky independently "
					"(clouds, sun, surface, atmosphere) at the cost of higher memory usage",
		update=general.should_load_composite_updated,
	)
	rotation: bpy.props.FloatProperty(
		name='Rotation',
		min=0, max=360,
		description='Rotation of the entire sky/environment around the 3d scene. This is a shortcut, the rotation can be set also directly in the world material',
		subtype='FACTOR',
		update=general.sky_rotation_updated,
	)
	sun_strength: bpy.props.FloatProperty(
		name='Sun strength', min=0, description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=5,
		update=general.composite_sky_colors_updated,
	)
	sun_red_percent: bpy.props.FloatProperty(
		name='Sun red %', min=0, max=100, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	sun_green_percent: bpy.props.FloatProperty(
		name='Sun green %', min=0, max=100, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	sun_blue_percent: bpy.props.FloatProperty(
		name='Sun blue %', min=0, max=100, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	atmo_red_percent: bpy.props.FloatProperty(
		name='Atmosphere red %', min=0, max=200, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	atmo_green_percent: bpy.props.FloatProperty(
		name='Atmosphere green %', min=0, max=200, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	atmo_blue_percent: bpy.props.FloatProperty(
		name='Atmosphere blue %', min=0, max=200, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	atmo_saturation: bpy.props.FloatProperty(
		name='Atmosphere saturation %', min=0, max=150, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	atmoDirect_v: bpy.props.FloatProperty(
		name='Atmosphere direct light %', min=0, max=1000, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	atmoIndirect_v: bpy.props.FloatProperty(
		name='Atmosphere indirect light %', min=0, max=1000, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	cloudDirect_v: bpy.props.FloatProperty(
		name='Direct light on clouds %', min=0, max=400, subtype='FACTOR',
		description='Shortcut to the world material node "Clouds direct HSV"\'s value parameter. Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	cloudIndirect_v: bpy.props.FloatProperty(
		name='Indirect light on clouds %', min=0, max=400, subtype='FACTOR',
		description='Shortcut to the world material node "Clouds indirect HSV"\'s value parameter. Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	# clouds_red_percent: bpy.props.FloatProperty(
	# 	name='Clouds red %', min=0, max=200, subtype='FACTOR',
	# 	description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
	# 	default=100, update=composite_sky_colors_updated,
	# )
	# clouds_green_percent: bpy.props.FloatProperty(
	# 	name='Clouds green %', min=0, max=200, subtype='FACTOR',
	# 	description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
	# 	default=100, update=composite_sky_colors_updated,
	# )
	# clouds_blue_percent: bpy.props.FloatProperty(
	# 	name='Clouds blue %', min=0, max=200, subtype='FACTOR',
	# 	description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
	# 	default=100, update=composite_sky_colors_updated,
	# )
	surfDirect_red_percent: bpy.props.FloatProperty(
		name='Surface direct red %', min=0, max=200, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	surfDirect_green_percent: bpy.props.FloatProperty(
		name='Surface direct green %', min=0, max=200, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	surfDirect_blue_percent: bpy.props.FloatProperty(
		name='Surface direct blue %', min=0, max=200, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	surfDirect_value: bpy.props.FloatProperty(
		name='Surface direct value %', min=0, max=500, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	surfDirect_saturation: bpy.props.FloatProperty(
		name='Surface direct saturation %', min=0, max=400, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	surfIndirect_red_percent: bpy.props.FloatProperty(
		name='Surface indirect red %', min=0, max=200, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	surfIndirect_green_percent: bpy.props.FloatProperty(
		name='Surface indirect green %', min=0, max=200, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	surfIndirect_blue_percent: bpy.props.FloatProperty(
		name='Surface indirect blue %', min=0, max=200, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	surfIndirect_value: bpy.props.FloatProperty(
		name='Surface indirect value %', min=0, max=500, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	surfIndirect_saturation: bpy.props.FloatProperty(
		name='Surface indirect saturation %', min=0, max=400, subtype='FACTOR',
		description='Temporarily reduce or disable multiple importance to view changes faster while you tweak this value',
		default=100, update=general.composite_sky_colors_updated,
	)
	ui_property_groups: bpy.props.EnumProperty(
		name='_',
		description='',
		items=[
			('sun', 'Sun', '', 1),
			('atmosphere', 'Atmosphere', '', 2),
			('clouds', 'Clouds', '', 3),
			('surface', 'Surface', '', 4),
		])


class SkiesCollectionsListItem(bpy.types.PropertyGroup):
	collection_name: bpy.props.StringProperty(
		name="Name",
		description="Name of this collection",
	)
	collection_4k_is_enabled: bpy.props.BoolProperty(
		name="4k",
		description="Enable 4k resolution, if it is installed",
	)
	collection_4k_is_installed: bpy.props.BoolProperty(
		name="",
		description="",
		default=False,
	)
	collection_8k_is_enabled: bpy.props.BoolProperty(
		name="8k",
		description="Enable 8k resolution, if it is installed",
	)
	collection_8k_is_installed: bpy.props.BoolProperty(
		name="",
		description="",
		default=False,
	)
	collection_12k_is_enabled: bpy.props.BoolProperty(
		name="12k",
		description="Enable 12k resolution, if it is installed",
	)
	collection_12k_is_installed: bpy.props.BoolProperty(
		name="",
		description="",
		default=False,
	)
	collection_16k_is_enabled: bpy.props.BoolProperty(
		name="16k",
		description="Enable 16k resolution, if it is installed",
	)
	collection_16k_is_installed: bpy.props.BoolProperty(
		name="",
		description="",
		default=False,
	)
	collection_other_resolutions_are_enabled: bpy.props.BoolProperty(
		name="Other",
		description="Enable other resolutions, if they are installed",
	)
	collection_other_res_are_installed: bpy.props.BoolProperty(
		name="",
		description="",
		default=False,
	)


class SS_UL_SkiesCollectionsList(bpy.types.UIList):
	def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
		# We could write some code to decide which icon to use here...
		custom_icon = icônes['images-stack'].icon_id

		# Make sure your code supports all 3 layout types
		if self.layout_type in {'DEFAULT', 'COMPACT'}:
			row = layout.row()
			row.label(text=item.name, icon_value=custom_icon)
		# split = row.split(0.5)
		# split.label(text=item.name, icon=custom_icon)
		# if item.collection_4k_is_installed:
		# 	col = split.column()
		# 	col.prop(item, 'collection_4k_is_enabled')
		# col = split.column()
		# col.enabled = item.collection_8k_is_installed
		# col.prop(item, 'collection_8k_is_enabled')
		# col = split.column()
		# col.enabled = item.collection_12k_is_installed
		# col.prop(item, 'collection_12k_is_enabled')
		# col = split.column()
		# col.enabled = item.collection_16k_is_installed
		# col.prop(item, 'collection_16k_is_enabled')
		# col = split.column()
		# col.enabled = item.collection_other_res_are_installed
		# col.prop(item, 'collection_other_resolutions_are_enabled')

		elif self.layout_type in {'GRID'}:
			layout.alignment = 'CENTER'
			layout.label(text="", icon_value=custom_icon)


def recreate_icons_and_load_common():
	global icônes
	if icônes:
		bpy.utils.previews.remove(icônes)
	icônes = bpy.utils.previews.new()
	icônes.load('logo', str(Path(__file__).parent / 'icons' / 'logo.png'), 'IMAGE')
	icônes.load('images-stack', str(Path(__file__).parent / 'icons' / 'images-stack.png'), 'IMAGE')
	icônes.load('tick', str(Path(__file__).parent / 'icons' / 'tick-white.png'), 'IMAGE')


def load_thumbnails_for_selected_collection():
	global icônes
	recreate_icons_and_load_common()

	previews_items = []
	try:
		selected_collection = bpy.context.scene.SceneSkies_collections[bpy.context.scene.SceneSkies_collections_index]
		previews_paths = []
		collections_dirs = [path for path in Path(bpy.context.preferences.addons['sceneskies'].preferences.storage_path).glob('*') if path.is_dir()]
		for collection_dir in collections_dirs:
			if collection_dir.name != selected_collection.name:
				continue
			resolution_dirs = [path for path in collection_dir.glob('*') if path.is_dir()]
			for resolution_dir in resolution_dirs:
				# if resolution_dir.name == 4000 and not selected_collection.collection_4k_is_enabled:
				# 	continue
				skies_folders = [path for path in resolution_dir.glob('*') if path.is_dir()]
				for sky_folder in skies_folders:
					previews_paths.append(str(sky_folder / 'equi_main_preview.jpg'))
		for preview_path in previews_paths:
			previews_items.append((preview_path, preview_path, '', icônes.load(preview_path, preview_path, 'IMAGE').icon_id, len(previews_items) + 1))
		bpy.types.Scene.SceneSkies_previews = bpy.props.EnumProperty(
			name='',
			description='',
			items=previews_items)
	except Exception as e:
		# print(e)
		pass

	global should_reload_thumbnails
	should_reload_thumbnails = False


classes_to_register = (
	SceneSkiesAddonPreferences,
	SS_PT_World,
	SkiesCollectionsListItem,
	SS_UL_SkiesCollectionsList,
	PropertyGroup_Scene,
	operators.SS_OT_check_latest_version,
	operators.SS_OT_render_cube_faces,
	operators.SS_OT_detect_collections,
	operators.SS_OT_create_data_folder,
	operators.SS_OT_add_samples_in_data_folder,
	operators.SS_OT_choisir_monde,
	operators.SS_OT_random_rotation,
	operators.SS_OT_random_sun_dawn_color,
	operators.SS_OT_random_sun_noon_color,
	operators.SS_OT_random_sun_dusk_color,
	operators.SS_OT_random_atmo_color,
	operators.SS_OT_random_clouds_color,
	operators.SS_OT_reset_sun,
	operators.SS_OT_reset_atmo,
	operators.SS_OT_reset_clouds,
	operators.SS_OT_reset_surf,
	operators.SS_OT_open_skies_folder,
)


def register():
	# pass
	for c in classes_to_register:
		bpy.utils.register_class(c)
	recreate_icons_and_load_common()

	bpy.types.Scene.SceneSkies = bpy.props.PointerProperty(type=PropertyGroup_Scene)

	bpy.types.Scene.SceneSkies_collections = bpy.props.CollectionProperty(type=SkiesCollectionsListItem)
	bpy.types.Scene.SceneSkies_collections_index = bpy.props.IntProperty(
		name="Index for SceneSkies_collections",
		# update=general.collections_index_updated,
		update=collections_index_updated,
	)

	# load_thumbnails_for_selected_collection() => NON parce que il n'y a pas de context.scene dans cette méthode, donc je l'appelle depuis le draw du panel
	global should_reload_thumbnails
	should_reload_thumbnails = True


def unregister():
	del bpy.types.Scene.SceneSkies
	bpy.utils.previews.remove(icônes)
	for c in reversed(classes_to_register):
		bpy.utils.unregister_class(c)

	del bpy.types.Scene.SceneSkies_collections
	del bpy.types.Scene.SceneSkies_collections_index
	try:
		del bpy.types.Scene.SceneSkies_previews
	except: pass


if __name__ == '__main__':
	register()
