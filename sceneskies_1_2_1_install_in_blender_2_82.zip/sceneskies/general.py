import bpy
import os
import math
from pathlib import Path

latest_checked_version_is_newer = None
latest_checked_version = None
error_occured_during_version_checking = None


def composite_sky_colors_updated(self, context):
	world_nodes = bpy.context.scene.world.node_tree.nodes

	# reset sun strength
	if bpy.context.scene.SceneSkies.should_load_composite:
		bpy.context.scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value = bpy.context.scene.SceneSkies.sun_strength
	else:
		bpy.context.scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value = 5

	try:
		# sun color
		colors = {
			0: bpy.context.scene.SceneSkies.sun_red_percent / 100,
			1: bpy.context.scene.SceneSkies.sun_green_percent / 100,
			2: bpy.context.scene.SceneSkies.sun_blue_percent / 100,
		}
		for curveNb, color in colors.items():
			bpy.context.scene.world.node_tree.nodes['final curves'].mapping.curves[curveNb].points[1].location = (1, color)
		bpy.context.scene.world.node_tree.nodes['final curves'].mapping.update()

		# atmo
		colors = {
			0: bpy.context.scene.SceneSkies.atmo_red_percent / 100,
			1: bpy.context.scene.SceneSkies.atmo_green_percent / 100,
			2: bpy.context.scene.SceneSkies.atmo_blue_percent / 100,
		}
		for curveNb, color in colors.items():
			bpy.context.scene.world.node_tree.nodes['equi_atmoIndirect curves'].mapping.curves[curveNb].points[1].location = (1, color)
			bpy.context.scene.world.node_tree.nodes['equi_atmoDirect curves'].mapping.curves[curveNb].points[1].location = (1, color)
		bpy.context.scene.world.node_tree.nodes['equi_atmoIndirect curves'].mapping.update()
		bpy.context.scene.world.node_tree.nodes['equi_atmoDirect curves'].mapping.update()

		bpy.context.scene.world.node_tree.nodes['equi_atmoDirect HSV'].inputs['Saturation'].default_value = bpy.context.scene.SceneSkies.atmo_saturation / 100
		bpy.context.scene.world.node_tree.nodes['equi_atmoIndirect HSV'].inputs['Saturation'].default_value = bpy.context.scene.SceneSkies.atmo_saturation / 100

		world_nodes['equi_atmoDirect HSV'].inputs['Value'].default_value = bpy.context.scene.SceneSkies.atmoDirect_v / 100
		world_nodes['equi_atmoIndirect HSV'].inputs['Value'].default_value = bpy.context.scene.SceneSkies.atmoIndirect_v / 100

		# clouds
		world_nodes['equi_cloudDirect HSV'].inputs['Value'].default_value = bpy.context.scene.SceneSkies.cloudDirect_v / 100
		world_nodes['equi_cloudIndirect HSV'].inputs['Value'].default_value = bpy.context.scene.SceneSkies.cloudIndirect_v / 100

		# surface
		colors = {
			0: bpy.context.scene.SceneSkies.surfDirect_red_percent / 100,
			1: bpy.context.scene.SceneSkies.surfDirect_green_percent / 100,
			2: bpy.context.scene.SceneSkies.surfDirect_blue_percent / 100,
		}
		for curveNb, color in colors.items():
			bpy.context.scene.world.node_tree.nodes['equi_surfDirect curves'].mapping.curves[curveNb].points[1].location = (1, color)
		colors = {
			0: bpy.context.scene.SceneSkies.surfIndirect_red_percent / 100,
			1: bpy.context.scene.SceneSkies.surfIndirect_green_percent / 100,
			2: bpy.context.scene.SceneSkies.surfIndirect_blue_percent / 100,
		}
		for curveNb, color in colors.items():
			bpy.context.scene.world.node_tree.nodes['equi_surfIndirect curves'].mapping.curves[curveNb].points[1].location = (1, color)
		bpy.context.scene.world.node_tree.nodes['equi_surfDirect curves'].mapping.update()
		bpy.context.scene.world.node_tree.nodes['equi_surfIndirect curves'].mapping.update()

		bpy.context.scene.world.node_tree.nodes['equi_surfDirect HSV'].inputs[
			'Saturation'].default_value = bpy.context.scene.SceneSkies.surfDirect_saturation / 100
		bpy.context.scene.world.node_tree.nodes['equi_surfIndirect HSV'].inputs[
			'Saturation'].default_value = bpy.context.scene.SceneSkies.surfIndirect_saturation / 100
		bpy.context.scene.world.node_tree.nodes['equi_surfDirect HSV'].inputs[
			'Value'].default_value = bpy.context.scene.SceneSkies.surfDirect_value / 100
		bpy.context.scene.world.node_tree.nodes['equi_surfIndirect HSV'].inputs[
			'Value'].default_value = bpy.context.scene.SceneSkies.surfIndirect_value / 100


	except:
		pass
	# forcer le viwport en rendu à se mettre à jour
	bpy.context.scene.world.use_nodes = False
	bpy.context.scene.world.use_nodes = True


def sky_rotation_updated(self, context):
	# try: bpy.context.scene.world.node_tree.nodes['sky_rotation'].rotation[2] = bpy.context.scene.SceneSkies.rotation * math.pi / 180
	try: bpy.context.scene.world.node_tree.nodes['sky_rotation'].inputs['Rotation'].default_value[2] = bpy.context.scene.SceneSkies.rotation * math.pi / 180
	except Exception as e: print(e)


def should_load_composite_updated(self, context):
	bpy.ops.world.ss_choisir_monde()


def utiliser_ciel(chemin_fichier_aperçu):
	sky_is_composite = bpy.context.scene.SceneSkies.should_load_composite
	world_name = 'SceneSkies advanced' if sky_is_composite else 'SceneSkies simple'
	bpy.ops.wm.link(filename=world_name,
		directory=str(Path(__file__).parent / 'lib3.blend' / 'World'),
		link=False, relative_path=False
	)
	monde = bpy.data.worlds[world_name]
	monde.name = 'SceneSkies'  # force le renommage unique de ce monde par Blender en .001, .002 ...
	bpy.context.scene.world = monde
	world_nodes = monde.node_tree.nodes

	if sky_is_composite:
		dossier_du_panorama = Path(chemin_fichier_aperçu).parent
		world_nodes = bpy.context.scene.world.node_tree.nodes

		for img_map_name in ['equi_atmoDirect', 'equi_atmoIndirect', 'equi_cloudDirect', 'equi_cloudIndirect', 'equi_surfDirect', 'equi_surfIndirect',
							 'equi_surfEmit']:
			img_path = dossier_du_panorama / Path(img_map_name+'.exr')
			img_node = world_nodes[img_map_name]
			if img_path.exists():
				img_node.mute = False
				img_node.image = bpy.data.images.load(filepath=str(img_path))
				img_node.image.name = 'SceneSkies ' + img_node.image.name
			else:
				img_node.mute = True

		# world_nodes['equi_atmoIndirect'].image = bpy.data.images.load(filepath=str(dossier_du_panorama / 'equi_atmoIndirect.exr'))
	# world_nodes['equi_atmoIndirect'].image.name = 'SceneSkies ' + world_nodes['equi_atmoIndirect'].image.name
	#
	# world_nodes['equi_cloudDirect'].image = bpy.data.images.load(filepath=str(dossier_du_panorama / 'equi_cloudDirect.exr'))
	# world_nodes['equi_cloudDirect'].image.name = 'SceneSkies ' + world_nodes['equi_cloudDirect'].image.name
	#
	# world_nodes['equi_cloudIndirect'].image = bpy.data.images.load(filepath=str(dossier_du_panorama / 'equi_cloudIndirect.exr'))
	# world_nodes['equi_cloudIndirect'].image.name = 'SceneSkies ' + world_nodes['equi_cloudIndirect'].image.name
	#
	# world_nodes['equi_surfDirect'].image = bpy.data.images.load(filepath=str(dossier_du_panorama / 'equi_surfDirect.exr'))
	# world_nodes['equi_surfDirect'].image.name = 'SceneSkies ' + world_nodes['equi_surfDirect'].image.name
	#
	# world_nodes['equi_surfIndirect'].image = bpy.data.images.load(filepath=str(dossier_du_panorama / 'equi_surfIndirect.exr'))
	# world_nodes['equi_surfIndirect'].image.name = 'SceneSkies ' + world_nodes['equi_surfIndirect'].image.name
	#
	# world_nodes['equi_surfEmit'].image = bpy.data.images.load(filepath=str(dossier_du_panorama / 'equi_surfEmit.exr'))
	# world_nodes['equi_surfEmit'].image.name = 'SceneSkies ' + world_nodes['equi_surfEmit'].image.name

	else:
		final_image_path = Path(chemin_fichier_aperçu).parent / 'equi_main.exr'
		imageMonde = bpy.data.images.load(str(final_image_path))
		imageMonde.name = 'SceneSkies ' + imageMonde.name
		world_nodes['equi_main'].image = imageMonde

	# clean: delete unused worlds
	if bpy.context.preferences.addons['sceneskies'].preferences.delete_old_worlds:
		worlds_to_delete = []
		for world in bpy.data.worlds:
			if world.users == 0 and world.name.startswith('SceneSkies'):
				worlds_to_delete.append(world)
		for world in worlds_to_delete:
			bpy.data.worlds.remove(world)
		# clean: delete unused images
		images_to_delete = []
		for img in bpy.data.images:
			if img.users == 0 and img.name.startswith('SceneSkies'):
				images_to_delete.append(img)
		for img in images_to_delete:
			bpy.data.images.remove(img)
